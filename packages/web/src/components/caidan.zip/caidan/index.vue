<template>
    <div :class="bem()">
        <div :class="[bem('cover-box'), showCover ? 'show' : '']" @click="clickCover">
            <div :class="bem('boxs')" @click.stop>
                <div :class="[bem('cat'), showLetter ? 'hide' : '']">
                    <img src="https://st-gdx.dancf.com/assets/20190925-174652-dbd3.gif" alt="">
                    <br>
                    <el-button style="margin: 20px 60px 20px 0" @click="openLetter" type="primary">马上拆开看看</el-button>
                </div>
                <div :class="[bem('letter-box'), showLetter ? 'show' : 'hide']">
                    <div :class="[bem('letter'), open ? 'open' : 'close']">
                        <div class="code-box">
                            <div class="code" @webkitTransitionEnd="drawOutTransitionEnd">
                                <h3>{{messageTitle.join('')}}</h3>
                                <p>{{message.join('')}}</p>
                                <h4>{{messageFrom.join('')}}</h4>
                            </div>
                        </div>
                        <div class="gai" :class="{'gai-opened': gaiOpen}" @webkitTransitionEnd="capTransitionEnd"/>
                        <div class="cover"/>
                    </div>
                </div>
            </div>
        </div>
        <div :class="bem('enter')" @click="caidanStart">
            <img src="./assets/cat.gif" alt="">
        </div>
        <div
            class="star"
            v-for="item in stars"
            :key="item.id"
            :style="{left: item.left + '%', 'animation-delay': item.delay + 's'}">
            {{rain[item.rain]}}</div>
    </div>
</template>

<script>

const title = 'hi，亲爱的门店&哥伦布宝宝们：'.split('');
const message = '感谢你们，在设计工坊还是一个BUG很多的熊孩子时接入，在帮他长大的过程中，你们给予了很多的包容和帮助。我们会记得每次一起面对挑战和未知的时候，一起并肩作战的感觉。请收好我们的小礼物吧~'.split('');
const from = '设计工坊'.split('');
function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
}
function uuid(len = 8, radix = 16) {
    var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
    var uuid = []; var i;
    radix = radix || chars.length;

    if (len) {
    // Compact form
        for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random() * radix];
    } else {
    // rfc4122, version 4 form
        var r;

        // rfc4122 requires these characters
        uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
        uuid[14] = '4';

        // Fill in random data. At i==19 set the high bits of clock sequence as
        // per rfc4122, sec. 4.1.5
        for (i = 0; i < 36; i++) {
            if (!uuid[i]) {
                r = 0 | Math.random() * 16;
                uuid[i] = chars[(i === 19) ? (r & 0x3) | 0x8 : r];
            }
        }
    }

    return uuid.join('');
}

export default class Caidan {
    private showCover: boolean = false;
    private open: boolean = false; // 控制信封的开启 和 关闭
    private gaiOpen: boolean = false; // 需要动态控制盖子的 z-inde
    private showLetter: boolean = false; // 是否显示信封
    private messageTitle: object = [];
    private message: object = [];
    private messageFrom: object = [];
    private stars: object = [];
    private rain: object = ['🌟', '💗', '🌞'];

    created() {
    }
    // 盖子动画结束
    capTransitionEnd() {
        if (this.open) {
            this.gaiOpen = true;
        }
    }
    // 信纸抽出动画结束
    drawOutTransitionEnd() {
        if (!this.open) {
            this.gaiOpen = false;
        } else {
            this.typeing().then(() => {
                // 文字看完2秒之后隐藏信封和遮罩
                window.setTimeout(() => {
                    this.open = false;
                    window.setTimeout(() => {
                        this.caidanEnd();
                    }, 3000);
                }, 2000);
            });
        }
    }
    // 点击背景遮罩
    clickCover() {
        // 如果没开始，可以关闭
        if (!this.showLetter) {
            this.showCover = false;
        }
    }
    // 查看信封
    openLetter() {
        this.showLetter = true;
        window.setTimeout(() => {
            this.open = true;
        }, 1000);
    }
    // 开始彩蛋
    caidanStart() {
        this.showCover = true;
        this.showLetter = false;
        this.messageTitle = [];
        this.message = [];
        this.messageFrom = [];
    }

    // 结束彩蛋
    caidanEnd() {
        this.showCover = false;
        this.stars = Array(50).fill(1).map(() => {
            return {
                id: uuid(),
                left: getRandomInt(100),
                delay: getRandomInt(50) / 10,
                rain: getRandomInt(3)
            };
        });
    }

    // 打字效果
    typeing() {
        return new Promise((resolve) => {
            let _title = [...title];
            let timer = window.setInterval(() => {
                if (_title.length) {
                    this.messageTitle.push(_title.shift());
                } else {
                    window.clearInterval(timer);
                    resolve();
                }
            }, 130);
        }).then(() => {
            return new Promise(resolve => {
                let _message = [...message];
                window.setTimeout(() => {
                    let timer = window.setInterval(() => {
                        if (_message.length) {
                            this.message.push(_message.shift());
                        } else {
                            window.clearInterval(timer);
                            resolve();
                        }
                    }, 150);
                }, 500);
            });
        }).then(() => {
            return new Promise(resolve => {
                let _from = [...from];
                window.setTimeout(() => {
                    let timer = window.setInterval(() => {
                        if (_from.length) {
                            this.messageFrom.push(_from.shift());
                        } else {
                            window.clearInterval(timer);
                            resolve();
                        }
                    }, 130);
                }, 1000);
            });
        });
    }
}
</script>

<style scope lang="less">
    @keyframes star {
      0% {
        transform: translateY(0);
        opacity: 0;
      }
      2% {
        transform: translateY(0);
        opacity: 1;
      }
      99% {
        transform: translateY(101vh);
         opacity: 1;
      }
      100% {
        transform: translateY(102vh);
        opacity: 0;
      }
    }
    .star {
      animation: star 4s 0s linear forwards;
      position: fixed;
      left: 50px;
      top:-50px;
      z-index: 9999999;
      font-size: 30px;
    }
    @b: caidan;

    .@{b} {
      &__cover-box {
        position: fixed;
        z-index: 9999;
        left: 0;
        top: 0;
        right: 0;
        bottom: 0;
        background-color: @mask-light;
        display: flex;
        justify-content: center;
        align-items: center;
        display: none;
        &.show {
          display: flex;
        }
      }

      &__enter {
        position: fixed;
        right: 3px;
        bottom: 60px;
        z-index: 10;
        cursor: pointer;
        img {
          width: 60px;
        }
      }


       &__boxs {
        width: 632px;
        height: 379px;

      }

      &__cat {
        text-align: center;
        > img {width: 400px;}
        &.hide {
          display: none;
        }
        p {
          color: #fff;
          font-size: 14px;
        }
      }

      &__letter-box {
        opacity: 1;
        transition: opacity 1s ease;
        &.hide {
          opacity: 0;
        }
      }

      &__letter {
        position: relative;
        height: 379px;
        transition: transform 1s ease;
        transition-delay: 1s;

         &.open {
            transform: translateY(80px);
            .gai {
              transform: rotateX(180deg);
            }
            .code {
              transform: translateY(-150px);
              transition-delay: 3s;
            }
            .cover {
              border-radius: 0 0 8px 8px;
            }
          }
        &.close {
          .gai {
            transition-delay: 1s;
            border-radius: 8px 8px 0 0;
          }
        }
        .gai {
          height: 232px;
          position: absolute;
          top:0;
          left: 0;
          right: 0;
          transition: transform 1s ease;
          transform-origin: top;
          z-index: 3;

          &.gai-opened {
            z-index: 0;
          }

          &::before,&::after {
            display: block;
            width: 100%;
            height: 100%;
            content: '';
            position: absolute;
            top:0;
            right: 0;
            left: 0;
            bottom: 0;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
          }
          &::before {
            background-image: url('./assets/gai-open.png');
          }
          &::after {
            background-image: url('./assets/gai-close.png');
          }
        }
        .cover {
          height: 100%;
          position: absolute;
          bottom:0;
          left: 0;
          right: 0;
          background: url('./assets/cover.png') no-repeat center center;
          background-size: cover;
          z-index: 2;
          border-radius:8px;
        }
        // 这个主要是为了加个底色
        .code-box {
          background-color: #F8E8C9;
          width: 100%;
          height: 100%;
          position: absolute;
          left: 0;
          top: 0;
          right: 0;
          bottom: 0;
          z-index: 1;
          padding: 0 10px;
          border-radius: 0 0 8px 8px;
        }
        .code {
          width: 100%;
          border-radius: 8px;
          height: 100%;
          transition: transform 1s ease;
          background-color: #FFFEFB;
          padding:30px 40px;
          color: #794A1C;

          h3,p,h4 {
            font-family: 'STKaiti';
            margin: 0;
            padding: 0;
            font-size: 20px;
            font-weight: normal;
            line-height: 1.2;
          }
          p {
            text-indent: 30px;
            margin-top: 10px;
            line-height: 1.5;
          }
          h4 {
            font-size: 16px;
            text-align: right;
            padding-right: 40px;
          }
        }
      }
    }

</style>
